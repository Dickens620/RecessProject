#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql.h>

typedef struct Patients
{
	char patientName[100];
	char patientStatus[30];
	char patientGender[10];
	char date[50];

} patient;

patient patients[100];

int main()
{
	FILE *serverFile;
	serverFile = fopen("serverfile.txt", "r+");
	puts("Hello");
	
	char buffer[255], dtm[255];
	
	int index = 0;
	while (fgets(buffer, 255, serverFile) != NULL)
	{
		//puts(buffer);
		//printf(buffer);
		strcpy(dtm, buffer);
		sscanf(dtm, "%s %s %s %s\n", patients[index].patientName, patients[index].date,
			   patients[index].patientGender, patients[index].patientStatus);
		printf("Name: %s \nDate: %s \nGender: %s\nStatus: %s\n",
			   patients[index].patientName, patients[index].date, patients[index].patientGender,
			   patients[index].patientStatus);
		index++;
	}
}
