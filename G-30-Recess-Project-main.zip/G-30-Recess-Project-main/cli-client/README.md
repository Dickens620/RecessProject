#This is the README for the cli-client.
#It provides instructions on building and running the client program

## Building
$ make clean

$ make

## Running
$ ./main

